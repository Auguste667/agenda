﻿using System;
using System.Collections.Generic;

namespace tets.agendaDB;

public partial class Contacte
{
    public int Id { get; set; }

    public string Nom { get; set; } = null!;

    public string Prenom { get; set; } = null!;

    public DateOnly? NumTel { get; set; }

    public string? Mail { get; set; }

    public virtual ICollection<ResauxSociaux> ResauxSociauxes { get; set; } = new List<ResauxSociaux>();
}

﻿using System;
using System.Collections.Generic;

namespace tets.agendaDB;

public partial class ResauxSociaux
{
    public int Id { get; set; }

    public string? Tiktok { get; set; }

    public string? Instagram { get; set; }

    public string? Snapchat { get; set; }

    public string? X { get; set; }

    public string? Discord { get; set; }

    public int ContacteId { get; set; }

    public virtual Contacte Contacte { get; set; } = null!;
}

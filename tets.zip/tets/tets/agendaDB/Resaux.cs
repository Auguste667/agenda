﻿using System;
using System.Collections.Generic;

namespace tets.agendaDB;

public partial class Resaux
{
    public int Id { get; set; }

    public string Nom { get; set; } = null!;

    public string Url { get; set; } = null!;

    public virtual ICollection<Profil> Profils { get; set; } = new List<Profil>();
}

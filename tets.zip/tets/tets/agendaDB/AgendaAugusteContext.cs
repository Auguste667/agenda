﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace tets.agendaDB;

public partial class AgendaAugusteContext : DbContext
{
    public AgendaAugusteContext()
    {
    }

    public AgendaAugusteContext(DbContextOptions<AgendaAugusteContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Contact> Contacts { get; set; }

    public virtual DbSet<Profil> Profils { get; set; }

    public virtual DbSet<Resaux> Resauxes { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseMySql("server=localhost;port=3306;user=root;database=agenda-auguste", Microsoft.EntityFrameworkCore.ServerVersion.Parse("8.0.21-mysql"));

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder
            .UseCollation("utf8mb4_0900_ai_ci")
            .HasCharSet("utf8mb4");

        modelBuilder.Entity<Contact>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PRIMARY");

            entity.ToTable("contact");

            entity.Property(e => e.Id).HasColumnName("id");
            entity.Property(e => e.Age).HasColumnName("age");
            entity.Property(e => e.Mail)
                .HasMaxLength(45)
                .HasColumnName("mail");
            entity.Property(e => e.Nom)
                .HasMaxLength(45)
                .HasColumnName("nom");
            entity.Property(e => e.Pays)
                .HasMaxLength(45)
                .HasColumnName("pays");
            entity.Property(e => e.Prenom)
                .HasMaxLength(45)
                .HasColumnName("prenom");
            entity.Property(e => e.Sex)
                .HasColumnType("enum('H','F')")
                .HasColumnName("sex");
            entity.Property(e => e.Statut)
                .HasColumnType("enum('F','A','C','T')")
                .HasColumnName("statut");
            entity.Property(e => e.Tel)
                .HasMaxLength(45)
                .HasColumnName("tel");
            entity.Property(e => e.TelFix)
                .HasMaxLength(45)
                .HasColumnName("tel fix");
        });

        modelBuilder.Entity<Profil>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PRIMARY");

            entity.ToTable("profil");

            entity.HasIndex(e => e.ResauxId, "fk_profil_resaux1_idx");

            entity.HasIndex(e => e.ContactId, "fk_table1_contact_idx");

            entity.Property(e => e.Id).HasColumnName("id");
            entity.Property(e => e.ContactId).HasColumnName("contact_id");
            entity.Property(e => e.ResauxId).HasColumnName("resaux_id");
            entity.Property(e => e.Sudo)
                .HasMaxLength(45)
                .HasColumnName("sudo");

            entity.HasOne(d => d.Contact).WithMany(p => p.Profils)
                .HasForeignKey(d => d.ContactId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("fk_table1_contact");

            entity.HasOne(d => d.Resaux).WithMany(p => p.Profils)
                .HasForeignKey(d => d.ResauxId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("fk_profil_resaux1");
        });

        modelBuilder.Entity<Resaux>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PRIMARY");

            entity.ToTable("resaux");

            entity.Property(e => e.Id).HasColumnName("id");
            entity.Property(e => e.Nom)
                .HasMaxLength(45)
                .HasColumnName("nom");
            entity.Property(e => e.Url)
                .HasMaxLength(45)
                .HasColumnName("URL");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}

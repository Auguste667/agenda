﻿using System;
using System.Collections.Generic;

namespace tets.agendaDB;

public partial class Contact
{
    public int Id { get; set; }

    public string Nom { get; set; } = null!;

    public string Prenom { get; set; } = null!;

    public DateOnly Age { get; set; }

    public string Tel { get; set; } = null!;

    public string? TelFix { get; set; }

    public string Mail { get; set; } = null!;

    public string Pays { get; set; } = null!;

    public string Sex { get; set; } = null!;

    public string? Statut { get; set; }

    public virtual ICollection<Profil> Profils { get; set; } = new List<Profil>();
}

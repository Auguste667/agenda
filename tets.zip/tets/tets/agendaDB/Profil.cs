﻿using System;
using System.Collections.Generic;

namespace tets.agendaDB;

public partial class Profil
{
    public int Id { get; set; }

    public int ContactId { get; set; }

    public int ResauxId { get; set; }

    public string Sudo { get; set; } = null!;

    public virtual Contact Contact { get; set; } = null!;

    public virtual Resaux Resaux { get; set; } = null!;
}

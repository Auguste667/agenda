﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

using tets.agendaDB;

namespace tets
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
    
        }

        private void btnAjouter_Click(object sender, RoutedEventArgs e)
        {
            // TODO: Ajouter la logique pour l'ajout d'un contact
        }

        private void btnSupprimer_Click(object sender, RoutedEventArgs e)
        {
            // TODO: Ajouter la logique pour la suppression d'un contact
        }

        private void btnModifier_Click(object sender, RoutedEventArgs e)
        {
            // TODO: Ajouter la logique pour la modification d'un contact
        }

        private void btnLister_Click(object sender, RoutedEventArgs e)
        {
            // TODO: Ajouter la logique pour lister tous les contacts
        }
    }
}